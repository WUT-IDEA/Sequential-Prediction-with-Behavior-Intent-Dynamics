# DuroNet-for-crime-prediction
The source code of the paper "DuroNet: A Dual-robust Enhanced Spatial-temporal Learning Network for Urban Crime Prediction"

All operators can be finished in the executor.py file. 

Before running the run_drnet method, you should run the date_list_creater method to preprocess the raw data.

The data preprocess process can be found in the preprocess.py file.

The training process is in the run.py file.

The drnet.py file is our final model.
